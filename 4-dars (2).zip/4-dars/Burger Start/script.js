const product = {
    plainBurger: {
        name: 'GAMBURGER',
        price: 10000,
        kcall: 400,
        amount:0,
        get calcSum() {
            return this.price * this.amount
        },
        get calcKcall() {
            return this.kcall * this.amount
        }
    },
    freshBurger: {
        name: 'GAMBURGER FRESH',
        price: 20500,
        kcall: 600,
        amount: 0,  
        get calcSum() {
            return this.price * this.amount
        },
        get calcKcall() {
            return this.kcall * this.amount
        }
    },
    freshCombo: {
        name: 'FRESH COMBO',
        price: 31900,
        kcall: 800,
        amount: 0,  
        get calcSum() {
            return this.price * this.amount
        },
        get calcKcall() {
            return this.kcall * this.amount
        }
    }
}

let btn = document.querySelectorAll('.main__product-btn');

// console.log(btn.length)


for(let i = 0; i < btn.length; i++) {

    btn[i].addEventListener('click', function () {

        prepare(this)

    })

}

function prepare(el) {
    // console.log(el)

    let parent = el.closest('.main__product');
    let parentId = parent.getAttribute('id');
    
    let num = parent.querySelector('.main__product-num');

    let sym = el.getAttribute('data-symbol')
    let price = parent.querySelector('.main__product-price span');
    let kcall = parent.querySelector('.main__product-kcall span');
    let amount = product[parentId].amount

    if(sym == '+' && amount < 20){
        amount++
        // num.innerHTML++
    } else if(sym == '-' && amount > 0) {
        amount--
        // num.innerHTML--
    }

    num.innerHTML = amount

    product[parentId].amount = amount

    // console.log(kcall)
    price.innerHTML = product[parentId].calcSum
    kcall.innerHTML = product[parentId].calcKcall

}


let addCart = document.querySelector('.addCart');
let receipt = document.querySelector('.receipt');
let receiptWindow = receipt.querySelector('.receipt__window');
let receiptWindowOut = receipt.querySelector('.receipt__window-out');
let receiptWindowBtn = receipt.querySelector('.receipt__window-btn');

// console.log(addCart, receipt, receiptWindow);

addCart.addEventListener('click', function () {
    
    receipt.style.display = 'flex'
    setTimeout(() =>  {
        receipt.style.opacity = 1
        receiptWindow.style.top = '10%'
    }, 300);


    let menu = `Your card:\n`
    let totalPrice = 0;
    let totalKcall = 0;


    for (const key in product) {
        // console.log(product[key].name)
        if(product[key].amount) {
            menu = menu + `${product[key].name} ${product[key].amount}dona\n`
            totalPrice = totalPrice + product[key].calcSum
            totalKcall = totalKcall + product[key].calcKcall
        }
    }

    receiptWindowOut.innerHTML = `${menu}\nTotal price: ${totalPrice}\n Colories: ${totalKcall}`

})